package swch.bcit.ca.swchdatabases;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TodoActivity extends AppCompatActivity {

    TodoDatabase datebase;
    EditText todoName;
    EditText todoPriority;
    EditText todoDueDate;
    EditText todoId;
    Button addTodo;
    Button getTodo;
    Button deleteTodo;
    Button updateTodo;
    Button note;
    Button event;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo);
        datebase = new TodoDatabase(getApplicationContext());

        todoName = (EditText) findViewById(R.id.todoname);
        todoPriority = (EditText) findViewById(R.id.todopriority);
        todoDueDate = (EditText) findViewById(R.id.tododate);
        todoId = (EditText) findViewById(R.id.todoid);

        addTodo = (Button) findViewById(R.id.todoadd);
        getTodo = (Button) findViewById(R.id.todoget);
        deleteTodo = (Button) findViewById(R.id.tododelete);
        updateTodo = (Button) findViewById(R.id.todoupdate);
        note = (Button) findViewById(R.id.note);
        event = (Button) findViewById(R.id.event);

        addTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Todo todo = new Todo(todoName.getText().toString(),
                                         Integer.parseInt(todoPriority.getText().toString()),
                                         todoDueDate.getText().toString());
                    datebase.addDataEntry(todo);
                    toastMessage("Data added.");
                } catch (DataExistenceException | IllegalDateFormatException | IllegalPriorityException e) {
                    toastMessage(e.getMessage());
                }
            }
        });

        getTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Todo todo = datebase.getTodo(Integer.parseInt(todoId.getText().toString()));
                    toastMessage("Name: " + todo.getName() + "\n" + "Priority: " + todo.getPriority() + "\n" + "Date: " + todo.getDueDate());
                } catch (DataExistenceException | IllegalDateFormatException | IllegalPriorityException e) {
                    toastMessage(e.getMessage());
                }
            }
        });

        deleteTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    datebase.deleteDataEntry(Integer.parseInt(todoId.getText().toString()));
                    toastMessage("Data deleted.");
                } catch (DataExistenceException e) {
                    toastMessage(e.getMessage());
                }
            }
        });

        updateTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newTodoName = todoName.getText().toString();
                int newTodoPriority = Integer.parseInt(todoPriority.getText().toString());
                String newTodoDueDate = todoDueDate.getText().toString();

                try {
                    datebase.updateTodo(newTodoName, newTodoPriority, newTodoDueDate, Integer.parseInt(todoId.getText().toString()));
                    toastMessage("Data updated.");
                } catch (DataExistenceException | IllegalPriorityException | IllegalDateFormatException e) {
                    toastMessage(e.getMessage());
                }
            }
        });

        note.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), NoteActivity.class));
            }
        });

        event.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), EventActivity.class));
            }
        });
    }

    private void toastMessage(String msg) {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }
}