package swch.bcit.ca.swchdatabases;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EventActivity extends AppCompatActivity {

    EventDatabase datebase;
    EditText eventName;
    EditText eventPriority;
    EditText eventDate;
    EditText eventId;
    Button addEvent;
    Button getEvent;
    Button deleteEvent;
    Button updateEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);
        datebase = new EventDatabase(getApplicationContext());

        eventName = (EditText) findViewById(R.id.eventname);
        eventPriority = (EditText) findViewById(R.id.eventpriority);
        eventDate = (EditText) findViewById(R.id.eventdate);
        eventId = (EditText) findViewById(R.id.eventid);

        addEvent = (Button) findViewById(R.id.eventadd);
        getEvent = (Button) findViewById(R.id.eventget);
        deleteEvent = (Button) findViewById(R.id.eventdelete);
        updateEvent = (Button) findViewById(R.id.eventupdate);

        addEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Event event = new Event(eventName.getText().toString(),
                            Integer.parseInt(eventPriority.getText().toString()),
                            eventDate.getText().toString());
                    datebase.addDataEntry(event);
                    toastMessage("Data added.");
                } catch (DataExistenceException | IllegalDateFormatException | IllegalPriorityException e) {
                    toastMessage(e.getMessage());
                }
            }
        });

        getEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Event event = datebase.getEvent(Integer.parseInt(eventId.getText().toString()));
                    toastMessage("Name: " + event.getName() + "\n" + "Priority: " + event.getPriority() + "\n" + "Date: " + event.getEventDate());
                } catch (DataExistenceException | IllegalDateFormatException | IllegalPriorityException e) {
                    toastMessage(e.getMessage());
                }
            }
        });

        deleteEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    datebase.deleteDataEntry(Integer.parseInt(eventId.getText().toString()));
                    toastMessage("Data deleted.");
                } catch (DataExistenceException e) {
                    toastMessage(e.getMessage());
                }
            }
        });

        updateEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newEventName = eventName.getText().toString();
                int newEventPriority = Integer.parseInt(eventPriority.getText().toString());
                String newEventDate = eventDate.getText().toString();

                try {
                    datebase.updateEvent(newEventName, newEventPriority, newEventDate, Integer.parseInt(eventId.getText().toString()));
                    toastMessage("Data updated.");
                } catch (DataExistenceException | IllegalPriorityException | IllegalDateFormatException e) {
                    toastMessage(e.getMessage());
                }
            }
        });
    }

    private void toastMessage(String msg) {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }
}