package swch.bcit.ca.swchdatabases;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class NoteActivity extends AppCompatActivity {

    NoteDatabase datebase;
    EditText noteName;
    EditText notePriority;
    EditText noteContents;
    EditText noteId;
    Button addNote;
    Button getNote;
    Button deleteNote;
    Button updateNote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        datebase = new NoteDatabase(getApplicationContext());

        noteName = (EditText) findViewById(R.id.notename);
        notePriority = (EditText) findViewById(R.id.notepriority);
        noteContents = (EditText) findViewById(R.id.notecontents);
        noteId = (EditText) findViewById(R.id.noteid);

        addNote = (Button) findViewById(R.id.noteadd);
        getNote = (Button) findViewById(R.id.noteget);
        deleteNote = (Button) findViewById(R.id.notedelete);
        updateNote = (Button) findViewById(R.id.noteupdate);

        addNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Note note = new Note(noteName.getText().toString(),
                                         Integer.parseInt(notePriority.getText().toString()),
                                         noteContents.getText().toString());
                    datebase.addDataEntry(note);
                    toastMessage("Data added.");
                } catch (DataExistenceException | IllegalPriorityException e) {
                    toastMessage(e.getMessage());
                }
            }
        });

        getNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Note note = datebase.getNote(Integer.parseInt(noteId.getText().toString()));
                    toastMessage("Name: " + note.getName() + "\n" + "Priority: " + note.getPriority() + "\n" + "Contents: " + note.getContents());
                } catch (DataExistenceException | IllegalPriorityException e) {
                    toastMessage(e.getMessage());
                }
            }
        });

        deleteNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    datebase.deleteDataEntry(Integer.parseInt(noteId.getText().toString()));
                    toastMessage("Data deleted.");
                } catch (DataExistenceException e) {
                    toastMessage(e.getMessage());
                }
            }
        });

        updateNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newNoteName = noteName.getText().toString();
                int newNotePriority = Integer.parseInt(notePriority.getText().toString());
                String newNoteContents = noteContents.getText().toString();

                try {
                    datebase.updateNote(newNoteName, newNotePriority, newNoteContents, Integer.parseInt(noteId.getText().toString()));
                    toastMessage("Data updated.");
                } catch (DataExistenceException | IllegalPriorityException e) {
                    toastMessage(e.getMessage());
                }
            }
        });
    }

    private void toastMessage(String msg) {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }
}